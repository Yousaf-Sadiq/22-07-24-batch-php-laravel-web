import { createRouter, createWebHistory } from 'vue-router'
// import WelcomePage from "../components/Home.vue"
import WelcomePage from "../components/Home.vue"

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'welcomePage',
      component: WelcomePage
    },
    {
      path: '/home',
      name: 'home2',
      component: WelcomePage
    },
   
   
  ]
})  

export default router
