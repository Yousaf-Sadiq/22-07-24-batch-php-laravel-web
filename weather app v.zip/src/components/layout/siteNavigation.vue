<template>
  <header class="sticky top-0 bg-weather-primary shadow-lg">
    <nav
      class="container flex flex-col sm:flex-row item-center text-center gap-4 text-white py-6"
    >
      <router-link :to="{ name: home }">
        <div class="flex items-center gap-3 flex-1 text-white">
          <i class="fa-solid fa-sun"></i>
          <p class="text-2xl">The local weather</p>
        </div>
      </router-link>
      <div class="flex flex-1  gap-3 justify-end">
        <i  v-on:click="$emit('toggle-modal')"
          class="fa fa-info-circle text-xl hover:text-weather-secondary duration-150 cursor-pointer"
          aria-hidden="true"
        ></i>

        <i class="fa fa-plus-circle  text-xl hover:text-weather-secondary duration-150 cursor-pointer" aria-hidden="true"></i>
      </div>
    </nav>
  </header>
</template>

<script setup>
import { RouterLink, RouterView } from "vue-router";

</script>
