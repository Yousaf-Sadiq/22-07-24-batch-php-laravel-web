<template>
  <div>
    <div class="container p-0 w-full">
      <form class="w-full">
        <label
          for="default-search"
          class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white"
          >Search</label
        >
        <div class="relative w-full">
          <div
            class="absolute w-full inset-y-0 start-0 flex items-center ps-3 pointer-events-none"
          >
            <svg
              class="w-4 h-4 text-red-700 dark:text-red-400"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 20 20"
            >
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
              />
            </svg>
          </div>

          <input
            type="search"
            v-model="query"
            @input="searchPlaces"
            placeholder="Search for places..."
            id="default-search"
            class="block  w-full p-4 ps-10 text-sm border-b-2 rounded-lg  
           
           outline-none focus:focus:ring-0 dark:focus:ring-0 dark:focus:ring-0"
            required
          />
          <!-- <button type="submit" class="text-white absolute end-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Search</button> -->
        </div>
      </form>
    </div>

    <!-- <input v-model="query" @input="searchPlaces" placeholder="Search for places..." /> -->

    <div class="container flex flex-wrap  flex-col ">
      <select id="underline_select" v-if="places.length" class="block px-4 py-2.5 px-0 w-full 
    text-sm text-gray-500 
     border-0 border-b-2
      border-gray-200 
      appearance-none 
      dark:text-gray-400 
      dark:border-gray-700 
      focus:outline-none focus:ring-0 focus:border-gray-200 peer">
      
   
      <option selected>Choose a country</option>
      <option
        v-for="place in places"
        :key="place.place_id"
        :value="place.display_name" 
        class="text-weather-primary"
      > {{ place.display_name }}</option>

    </select>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from "vue";
import axios from "axios";

// Define reactive variables
const query = ref("");
const places = ref([]);

// Function to search places
const searchPlaces = async () => {
  if (query.value.length < 3) {
    places.value = [];
    return;
  }

  try {
    const response = await axios.get(
      "https://nominatim.openstreetmap.org/search",
      {
        params: {
          q: query.value,
          format: "json",
          addressdetails: 1,
          limit: 10,
        },
      }
    );
    places.value = response.data;
  } catch (error) {
    console.error("Error fetching places:", error);
    places.value = [];
  }
};

// Watch for changes in the query to trigger search
watch(query, (newQuery) => {
  if (newQuery.length >= 3) {
    searchPlaces();
  }
});
</script>

<style scoped>
/* Add your styles here */
</style>
