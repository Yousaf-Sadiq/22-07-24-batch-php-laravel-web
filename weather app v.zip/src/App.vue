<template>
  <div class="flex flex-col min-h-screen font-Roboto bg-weather-primary">
    <SiteNavigation @toggle-modal="toggleModal" />
    <modal :modalActive="modalActive" @update:modalActive="modalActive = $event"  > 
    ABC checking thing if it works or not
    </modal>
    
 
    <RouterView />
  </div>
</template>

<script setup>

import { RouterLink, RouterView } from "vue-router";
import { ref } from 'vue';
import SiteNavigation from "./components/layout/siteNavigation.vue";
import modal from "./components/modals/BaseModal.vue";

const modalActive = ref(false);
// const isModalOpen = ref(false);

function toggleModal() {

  modalActive.value = !modalActive.value;
  console.warn(modalActive.value)
}

</script>
